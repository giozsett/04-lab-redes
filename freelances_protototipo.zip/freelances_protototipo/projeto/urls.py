from django.urls import path
from . import views

urlpatterns = [
    path('', views.VerAnuncioContratante.as_view(), name='anuncios-contratante'),
    path('anuncios/novo/', views.CadAnuncioView.as_view(), name='cad-anuncio'),
    path('anuncios/view/', views.VerAnuncioView.as_view(), name='ver-anuncio'),
    #path('anuncios/contratante', views.VerAnuncioContratante.as_view(), name='anuncios-contratante'),
    path('anuncios/freelancer', views.VerAnuncioFreelancer.as_view(), name='anuncios-freelancer'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('cadastro/', views.CadUsuarioView.as_view(), name='cad-usuario'),
    path('usuario/', views.MeuPerfilView.as_view(), name='meu-perfil'),
    path('editarperfil/', views.MeuPerfilEdit.as_view(), name='editar-perfil'),
    path('perfil/', views.PerfilUsuarioView.as_view(), name='perfil-usuario'),
]
