from django.shortcuts import render
from django.views.generic import TemplateView


# Login
class LoginView(TemplateView):
    template_name = 'login.html'

# Cadastrar novo usuário
class CadUsuarioView(TemplateView):
    template_name = 'cadusuario.html'


# Visualizar página de anúncios
#class AnunciosView(TemplateView):
    #template_name = 'anuncios.html'

# Página de Anúncios - Freelancer
class VerAnuncioFreelancer(TemplateView):
    template_name = 'anuncios/freelancer.html'

# Página de Anúncios - Contratante
class VerAnuncioContratante(TemplateView):
    template_name = 'anuncios/contratante.html'

# Cadastrar novo anúncio
class CadAnuncioView(TemplateView):
    template_name = 'anuncios/cadanuncio.html'

# Visualizar informações completas do anúncio
class VerAnuncioView(TemplateView):
    template_name = 'veranuncio.html'


# Visualizar perfil do usuário que está logado
class MeuPerfilView(TemplateView):
    template_name = 'meuperfil.html'

# Editar o perfil do usuário que está logado
class MeuPerfilEdit(TemplateView):
    template_name = 'meuperfiledt.html'


# Visualizar o perfil de outro usuário
class PerfilUsuarioView(TemplateView):
    template_name = 'perfilusuario.html'


