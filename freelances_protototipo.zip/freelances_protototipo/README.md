# Próximos passos
- Criar a página "Meus Anúncios" linkada no menu superior -> 
    (essa página conterá os anúncios postados pelo usuário e as solicitações que ele enviou em outros anúncios).
- Ajustar o layout de "Cadastro de Anúncio"
- Criar mockup do menu de chats
- Criar mockup da página de chat
- Criar mockup do menu de solicitações


# Importante!
- ao abrir em outra máquina, baixar o dotenv e criar o env.
- baixar a outra extensão do postgres



## Upwork
    - Bidding
    - Porcentagem sobre o valor do anúncio.

## Brybe
    - Untapped market
    - Niche

## Fiverr
    - Voltada para os clientes e para quem está gastando o dinheiro.
    - Package or hourly rates. Possible to know the whole scope before hiring.
    - 20% fee.

## Contra
    - Freelancer-first
    - No fees for freelancers

